# Praktikum JQUERY & AJAX

## PREQUISITES
- Node.js terinstall
- Jalankan Command berikut `npm install` dan `npm run start`

## JQUERY
- Terdapat 5 Card pada file index.html, tiap card memiliki deskripsi bagaimana tentang jQuery apa yang harus dibuat
- Code jQuery dimasukan pada file script.js
- Boleh menambah style pada file style.css

## AJAX
- Jalankan dan pahami code
- Buat agar card pertama melakukan fetch pada route `/profiles` yang memiliki 2 profile